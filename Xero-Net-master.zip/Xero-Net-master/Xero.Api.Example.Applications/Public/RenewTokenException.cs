﻿using System;

namespace Xero.Api.Example.Applications.Public
{
    public class RenewTokenException : Exception
    {
    }
}
