﻿namespace Xero.Api.Example.Creation.Creator
{
    public class PlaceName
    {
        public string Town { get; set; }
        public string County { get; set; }
        public string State { get; set; }
    }
}