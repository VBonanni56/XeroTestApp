﻿namespace Xero.Api.Infrastructure.Interfaces
{
    public interface IUser
    {
        string Name { get; set; }        
    }
}
