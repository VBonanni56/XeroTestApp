namespace Xero.Api.Infrastructure.ThirdParty.Dust.Core.SignatureBaseStringParts.Parameters.Timestamp {
	public interface TimestampSequence {
		string Next();
	}
}