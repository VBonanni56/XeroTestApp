﻿namespace Xero.Api.Infrastructure.ThirdParty.Dust.Core.SignatureBaseStringParts.Parameters.Nonce {
	public interface NonceSequence {
		string Next();
	}
}