﻿using System;

namespace Xero.Api.Infrastructure.ThirdParty.Dust.Core
{
    public class Request {
        public Uri Url { get; set; }
        public string Verb { get; set; }
    }
}