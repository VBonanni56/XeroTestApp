﻿using System.Runtime.Serialization;

namespace Xero.Api.Core.Model
{
    [DataContract(Namespace = "")]
    public sealed class SalesDetails : ItemDetails
    {
    }
}