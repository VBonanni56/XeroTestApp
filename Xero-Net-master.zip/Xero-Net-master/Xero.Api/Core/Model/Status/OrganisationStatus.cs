﻿using System.Runtime.Serialization;

namespace Xero.Api.Core.Model.Status
{
    public enum OrganisationStatus
    {
        [EnumMember(Value = "ACTIVE")]
        Active
    }
}