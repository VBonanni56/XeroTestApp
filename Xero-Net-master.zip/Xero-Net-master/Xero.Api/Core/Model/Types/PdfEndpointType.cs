﻿namespace Xero.Api.Core.Model.Types
{
    public enum PdfEndpointType
    {
        CreditNotes,
        Invoices,
        PurchaseOrders
    }
}