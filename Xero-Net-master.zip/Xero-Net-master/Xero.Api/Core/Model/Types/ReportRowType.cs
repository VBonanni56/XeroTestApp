namespace Xero.Api.Core.Model.Types
{
    public enum ReportRowType
    {
        Header,
        Row,
        Section,        
        Summary
    }
}