﻿##Tests for the American Payroll API
These are really code snippets in the form of runnable tests. The examples for each of the endpoints in [Developer](http://developer.xero.com/documentation/payroll-api/overview/) have been turned into individual tests.

## Getting the tests working

You will need to set the certificate and token values to be the ones which match your private application. The organisation will need to have Payroll enabled for this to work.

These will run against the live API, but may cause your rates to be reached if all ran at once.
