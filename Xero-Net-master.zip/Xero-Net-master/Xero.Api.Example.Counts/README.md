﻿##Console application example
This example uses a public application to list the counts from the various endpoints. It is a console application and the authentiation is done using oob callback. This will launch a browser on the users machine and prompt for the PIN. The token returned will be stored. If the applciation is run withing 30 minutes of the authorisation, the user will not be prompted to login.

You will need to enter appropriate values in the app.config file. As an exercise, change the application to private.
